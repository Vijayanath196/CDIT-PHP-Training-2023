

<?php
// echo dirname(dirname(__FILE__));

require_once '../app/bootstrap.php';
$init=new Core;
?> 