<!DOCTYPE html>
<html>
<body>

<?php
require APPROOT.'/views/inc/header.php';
require APPROOT.'/views/inc/footer.php';
?>


</body>
</html>

